<?php
$host_name ="localhost";
$user_name ="root";
$password ="";
$database_name ="form";

$connection_result = mysqli_connect($host_name,$user_name,$password,$database_name);

?>